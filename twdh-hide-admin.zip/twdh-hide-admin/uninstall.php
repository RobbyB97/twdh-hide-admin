<?php
/*
 *  This file executes on plugin uninstallation
 *
 */

if (!defined('WP_UNINSTALL_PLUGIN')) {
  die;
}
